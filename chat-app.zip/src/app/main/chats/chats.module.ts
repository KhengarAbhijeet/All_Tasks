import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ChatsRoutingModule } from './chats-routing.module';
import { ChatsComponent } from './chats.component';
import { FormsModule } from "@angular/forms";
import { DatePipe } from "@angular/common";

@NgModule({
  declarations: [
  ],
  imports: [
    CommonModule,
    ChatsRoutingModule,
    FormsModule
  ],
  providers:[
    DatePipe
  ]
})
export class ChatsModule { }
