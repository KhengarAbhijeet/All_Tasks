// <!-- The core Firebase JS SDK is always required and must be listed first -->
// <script src="https://www.gstatic.com/firebasejs/8.6.2/firebase-app.js"></script>

// <!-- TODO: Add SDKs for Firebase products that you want to use
//  https://firebase.google.com/docs/web/setup#available-libraries -->

// <script>
// Your web app's Firebase configuration
export const firebaseConfig = {
  production: false,
  firebase:
  {
    apiKey: "AIzaSyDWkz6PwaTa7T9FmsprR_LZbrpMyX1DS4M",
    authDomain: "fire-chat-b9a47.firebaseapp.com",
    projectId: "fire-chat-b9a47",
    storageBucket: "fire-chat-b9a47.appspot.com",
    messagingSenderId: "1022271929972",
    appId: "1:1022271929972:web:e71576df6ff9bc07c21b21"
  }
};
  // Initialize Firebase
//   firebase.initializeApp(firebaseConfig);
// </script>
